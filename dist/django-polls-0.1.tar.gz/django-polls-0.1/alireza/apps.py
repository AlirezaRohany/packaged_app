from django.apps import AppConfig


class AlirezaConfig(AppConfig):
    name = 'alireza'
